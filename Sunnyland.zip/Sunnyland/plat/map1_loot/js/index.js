const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')
const dpr = 2

canvas.width = 1024 * dpr
canvas.height = 576 * dpr


const oceanLayerData = {
  l_bg1: l_bg1,
}

const brambleLayerData = {
  l_bg2: l_bg2,
}

const layersData = {
   l_dirt: l_dirt,
   l_bg_dungeon: l_bg_dungeon,
   l_house_tree: l_house_tree,
   l_glass_decoration: l_glass_decoration,
   l_dungeun_walkZone: l_dungeun_walkZone,
   l_trap: l_trap,
   l_asscesorie: l_asscesorie,
   l_New_Layer_11: l_New_Layer_11,
   l_collisions: l_collisions,
};

const tilesets = {
  l_bg1: { imageUrl: './images/decorations.png', tileSize: 16 },
  l_bg2: { imageUrl: './images/decorations.png', tileSize: 16 },
  l_dirt: { imageUrl: './images/tileset.png', tileSize: 16 },
  l_bg_dungeon: { imageUrl: './images/91502bcd-212d-4dbe-1984-72395b921b00.png', tileSize: 16 },
  l_house_tree: { imageUrl: './images/decorations.png', tileSize: 16 },
  l_glass_decoration: { imageUrl: './images/tileset.png', tileSize: 16 },
  l_dungeun_walkZone: { imageUrl: './images/91502bcd-212d-4dbe-1984-72395b921b00.png', tileSize: 16 },
  l_trap: { imageUrl: './images/91502bcd-212d-4dbe-1984-72395b921b00.png', tileSize: 16 },
  l_asscesorie: { imageUrl: './images/91502bcd-212d-4dbe-1984-72395b921b00.png', tileSize: 16 },
  l_New_Layer_11: { imageUrl: './images/91502bcd-212d-4dbe-1984-72395b921b00.png', tileSize: 16 },
  l_collisions: { imageUrl: './images/tileset.png', tileSize: 16 },
};


// Tile setup
const collisionBlocks = []
const platforms = []
const blockSize = 16 // Assuming each tile is 16x16 pixels

collisions.forEach((row, y) => {
  row.forEach((symbol, x) => {
    if (symbol === 1) {
      collisionBlocks.push(
        new CollisionBlock({
          x: x * blockSize,
          y: y * blockSize,
          size: blockSize,
        }),
      )
    } else if (symbol === 2) {
      platforms.push(
        new Platform({
          x: x * blockSize,
          y: y * blockSize + blockSize,
          width: 16,
          height: 4,
        }),
      )
    }
  })
})

const renderLayer = (tilesData, tilesetImage, tileSize, context) => {
  // Calculate the number of tiles per row in the tileset
  // We use Math.ceil to ensure we get a whole number of tiles
  const tilesPerRow = Math.ceil(tilesetImage.width / tileSize)

  tilesData.forEach((row, y) => {
    row.forEach((symbol, x) => {
      if (symbol !== 0) {
        // Adjust index to be 0-based for calculations
        const tileIndex = symbol - 1

        // Calculate source coordinates
        const srcX = (tileIndex % tilesPerRow) * tileSize
        const srcY = Math.floor(tileIndex / tilesPerRow) * tileSize

        context.drawImage(
          tilesetImage, // source image
          srcX,
          srcY, // source x, y
          tileSize,
          tileSize, // source width, height
          x * 16,
          y * 16, // destination x, y
          16,
          16, // destination width, height
        )
      }
    })
  })
}
const renderStaticLayers = async (layersData) => {
  const offscreenCanvas = document.createElement('canvas')
  offscreenCanvas.width = canvas.width
  offscreenCanvas.height = canvas.height
  const offscreenContext = offscreenCanvas.getContext('2d')

  for (const [layerName, tilesData] of Object.entries(layersData)) {
    const tilesetInfo = tilesets[layerName]
    if (tilesetInfo) {
      try {
        const tilesetImage = await loadImage(tilesetInfo.imageUrl)
        renderLayer(
          tilesData,
          tilesetImage,
          tilesetInfo.tileSize,
          offscreenContext,
        )
      } catch (error) {
        console.error(`Failed to load image for layer ${layerName}:`, error)
      }
    }
  }

  // Optionally draw collision blocks and platforms for debugging
  // collisionBlocks.forEach(block => block.draw(offscreenContext));
  // platforms.forEach((platform) => platform.draw(offscreenContext))

  return offscreenCanvas
}
// END - Tile setup

// Change xy coordinates to move player's default position
const player = new Player({
  x: 100,
  y: 100,
  size: 32,
  velocity: { x: 0, y: 0 },
})

const keys = {
  w: {
    pressed: false,
  },
  a: {
    pressed: false,
  },
  d: {
    pressed: false,
  },
}

let lastTime = performance.now()
const camera = {
  x : 0,
  y : 0,
}
const SCROLL_POST_RIGHT = 400 
const SCROLL_POST_TOP = 100 
const SCROLL_POST_BOTTOM = 280 
let oceanBackgroundCanvas = null
let brambleBackgroundCanvas = null
function animate(backgroundCanvas) {
  // Calculate delta time
  const currentTime = performance.now()
  const deltaTime = (currentTime - lastTime) / 1000
  lastTime = currentTime

  // Update player position
  player.handleInput(keys)
  player.update(deltaTime, collisionBlocks)

  // Track scroll post distance
  if(player.x > SCROLL_POST_RIGHT ){
  const scrollPostDistance = player.x - SCROLL_POST_RIGHT
  camera.x = scrollPostDistance
}
if(player.y < SCROLL_POST_TOP && camera.y > 0 ){
  const scrollPostDistance = SCROLL_POST_TOP - player.y
  camera.y = scrollPostDistance
}
if(player.y > SCROLL_POST_BOTTOM ){
  const scrollPostDistance = player.y - SCROLL_POST_BOTTOM
  camera.y = -scrollPostDistance
}

  // Render scene
 c.save()
  c.scale(dpr, dpr)
  c.translate(-camera.x, camera.y)
  c.clearRect(0, 0, canvas.width, canvas.height)
  c.drawImage(oceanBackgroundCanvas, camera.x * 0.32, 0)
  c.drawImage(brambleBackgroundCanvas, camera.x * 0.16, 0)
  c.drawImage(backgroundCanvas, 0, 0)
  player.draw(c)
  c.restore()

  requestAnimationFrame(() => animate(backgroundCanvas))
}

const startRendering = async () => {
  try {
    oceanBackgroundCanvas = await renderStaticLayers(oceanLayerData)
    brambleBackgroundCanvas = await renderStaticLayers(brambleLayerData)
    const backgroundCanvas = await renderStaticLayers(layersData)
    if (!backgroundCanvas) {
      console.error('Failed to create the background canvas')
      return
    }

    animate(backgroundCanvas)
  } catch (error) {
    console.error('Error during rendering:', error)
  }
}

startRendering()

